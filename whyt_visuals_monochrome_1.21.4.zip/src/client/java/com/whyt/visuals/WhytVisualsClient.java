package com.whyt.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

public class WhytVisualsClient implements ClientModInitializer {

    // Monochrome (Oq, Kulrang, Qora) vizualizator rejimi
    @Override
    public void onInitializeClient() {
        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            int screenWidth = drawContext.getScaledWindowWidth();
            int screenHeight = drawContext.getScaledWindowHeight();

            RenderSystem.enableBlend();

            // Vizualizator parametrlari
            int barCount = 30;
            int barWidth = 6;
            int barSpacing = 3;
            int totalWidth = barCount * (barWidth + barSpacing);
            int startX = (screenWidth - totalWidth) / 2;
            long currentTime = System.currentTimeMillis();

            // Markaziy monoxrom aura (Bass pulsatsiyasi)
            float bassValue = (float) (Math.sin(currentTime / 200.0) * 0.5 + 0.5);
            int radius = (int) (15 + bassValue * 25);
            int centerX = screenWidth / 2;
            int centerY = screenHeight - 45;

            // Shaffof oq aura (Pulse effekti)
            drawContext.fill(
                centerX - radius, centerY - radius,
                centerX + radius, centerY + radius,
                0x22FFFFFF // Monoxrom shaffof oq
            );

            // Audio Spektr Ustunlari (Monochrome Theme: Oq, Kumush, Kulrang, Qora)
            for (int i = 0; i < barCount; i++) {
                // Har bir ustun uchun chastota to'lqinining balandligi
                double wave = Math.sin((currentTime / 120.0) + (i * 0.4)) * 0.5 + 0.5;
                int barHeight = (int) (wave * 35 + 8);

                int x1 = startX + i * (barWidth + barSpacing);
                int y1 = screenHeight - 15 - barHeight;
                int x2 = x1 + barWidth;
                int y2 = screenHeight - 15;

                // Monoxrom ranglar gradatsiyasi (Oq, Och kulrang, To'q kulrang)
                int color;
                if (i % 3 == 0) {
                    color = 0xFFFFFFFF; // Sof Oq
                } else if (i % 3 == 1) {
                    color = 0xCCDCDCDC; // Kumush / Och kulrang
                } else {
                    color = 0xAA666666; // To'q kulrang
                }

                // Ustunni chizish
                drawContext.fill(x1, y1, x2, y2, color);

                // Yuqori nuqta (Peak Dot - Oq)
                drawContext.fill(x1, y1 - 3, x2, y1 - 1, 0xFFFFFFFF);
            }

            RenderSystem.disableBlend();
        });
    }
}
